@echo off
REM 林舟工作流 —— 图形界面启动器（双击此文件 或 桌面快捷方式）
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM ── 升级清理（2026-10-16，兼容源码版→保护版跨越）────────────────────
REM   旧版分发的是 .py 源码，新版是 .pyc 保护版。两者同名并存时，
REM   Python 会**优先加载 .py**（旧代码）→ 更新看似成功实际不生效。
REM   规则：仅当同名 .pyc 存在时，删除该 .py（保护版没有源码要保留）。
for %%F in ("*.py") do if exist "%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("lib\*.py") do if exist "lib\%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("bin\*.py") do if exist "bin\%%~nF.pyc" del /q "%%~F" >nul 2>&1

set PY=
if exist ".\python\pythonw.exe" set PY=.\python\pythonw.exe
if not defined PY if exist ".\python\python.exe" set PY=.\python\python.exe
if not defined PY (
  where pythonw >nul 2>&1 && set PY=pythonw
)
if not defined PY (
  where python >nul 2>&1 && set PY=python
)
if not defined PY (
  echo [!] 未找到 Python 运行时，请重新安装本软件。
  pause
  exit /b 1
)

REM pythonw = 无控制台黑窗；界面用 Edge/Chrome 的 app 窗口打开
REM 保护版分发的界面入口是 ui_server.pyc（源码不随包）→ 优先用它
REM %* 透传参数（2026-10-19 加：重启时带 --port，保持重启前后同端口）
REM ── 启动 + 失败自检（2026-11-01）──────────────────────────────
REM   🔴 原写法 `start "" ...` + `exit /b 0`：异步启动后立即退出。
REM      若 Python 起不来（缺模块/版本不匹配/pyc 损坏），用户双击后
REM      黑窗一闪即逝、**什么都没有**，完全不知道发生了什么 —— 只能反复双击。
REM   现在：启动后等 4 秒探端口；没起来就前台重跑一次，把真实错误留在窗口里。
set UIARG=
if exist "lib\ui_server.pyc" (set UIARG="lib\ui_server.pyc") else (set UIARG="lib\ui_server.py")

start "" %PY% %UIARG% %*
timeout /t 4 /nobreak >nul

REM 探 8765~8774 任意端口是否有界面在应答
set UP=
for %%P in (8765 8766 8767 8768 8769 8770 8771 8772 8773 8774) do (
  if not defined UP (
    powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',%%P);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
    if not errorlevel 1 set UP=%%P
  )
)
if defined UP exit /b 0

echo.
echo  ============================================================
echo   [!] 界面没有启动成功，下面是详细错误信息
echo  ============================================================
echo.
REM 前台再跑一次（python 而非 pythonw，才能看到输出）
if exist ".\python\python.exe" (
  ".\python\python.exe" %UIARG% --no-browser %*
) else (
  python %UIARG% --no-browser %*
)
echo.
echo  ------------------------------------------------------------
echo   把上面的内容截图发给管理员。
echo   如果是刚升级后出现，可尝试：把本文件夹改名，
echo   再用「林舟工作流-Windows版.bak-日期」那个备份文件夹里的启动.bat。
echo  ------------------------------------------------------------
pause
exit /b 1
