@echo off
REM 林舟工作流 —— 图形界面启动器（双击此文件 或 桌面快捷方式）
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM ── 升级清理（2026-10-16，兼容源码版→保护版跨越）────────────────────
REM   旧版分发的是 .py 源码，新版是 .pyc 保护版。两者同名并存时，
REM   Python 会**优先加载 .py**（旧代码）→ 更新看似成功实际不生效。
REM   规则：仅当同名 .pyc 存在时，删除该 .py（保护版没有源码要保留）。
for %%F in ("*.py") do if exist "%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("lib\*.py") do if exist "lib\%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("bin\*.py") do if exist "bin\%%~nF.pyc" del /q "%%~F" >nul 2>&1

set PY=
if exist ".\python\pythonw.exe" set PY=.\python\pythonw.exe
if not defined PY if exist ".\python\python.exe" set PY=.\python\python.exe
if not defined PY (
  where pythonw >nul 2>&1 && set PY=pythonw
)
if not defined PY (
  where python >nul 2>&1 && set PY=python
)
if not defined PY (
  echo [!] 未找到 Python 运行时，请重新安装本软件。
  pause
  exit /b 1
)

REM pythonw = 无控制台黑窗；界面用 Edge/Chrome 的 app 窗口打开
REM 保护版分发的界面入口是 ui_server.pyc（源码不随包）→ 优先用它
REM %* 透传参数（2026-10-19 加：重启时带 --port，保持重启前后同端口）
if exist "lib\ui_server.pyc" (
  start "" %PY% "lib\ui_server.pyc" %*
) else (
  start "" %PY% "lib\ui_server.py" %*
)
exit /b 0
