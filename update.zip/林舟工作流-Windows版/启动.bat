@echo off
REM Linzhou Workflow - GUI launcher
REM NOTE: keep this file pure ASCII. Chinese comments in a .bat break cmd
REM       under GBK codepage (UTF-8 bytes contain & | < > which cmd treats
REM       as command separators, so REM lines get executed as commands).
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM -- cleanup: drop .py shadowed by .pyc (protected build has no source) --
for %%F in ("*.py") do if exist "%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("lib\*.py") do if exist "lib\%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("bin\*.py") do if exist "bin\%%~nF.pyc" del /q "%%~F" >nul 2>&1

set PY=
if exist ".\python\pythonw.exe" set PY=.\python\pythonw.exe
if not defined PY if exist ".\python\python.exe" set PY=.\python\python.exe
if not defined PY ( where pythonw >nul 2>&1 && set PY=pythonw )
if not defined PY ( where python >nul 2>&1 && set PY=python )
if not defined PY (
  echo [X] Python runtime not found. Please reinstall this software.
  pause
  exit /b 1
)

set UIARG=
if exist "lib\ui_server.pyc" (set UIARG="lib\ui_server.pyc") else (set UIARG="lib\ui_server.py")

start "" %PY% %UIARG% %*
timeout /t 4 /nobreak >nul

REM -- probe ports 8765..8774 via netstat (no PowerShell dependency) --
netstat -ano | findstr /r ":876[5-9] .*LISTENING" >nul 2>&1 && exit /b 0
netstat -ano | findstr /r ":877[0-4] .*LISTENING" >nul 2>&1 && exit /b 0

echo.
echo  ============================================================
echo   [!] UI failed to start. Details below:
echo  ============================================================
echo.
if exist ".\python\python.exe" (
  ".\python\python.exe" %UIARG% --no-browser %*
) else (
  python %UIARG% --no-browser %*
)
echo.
echo  ------------------------------------------------------------
echo   Screenshot this and send to admin.
echo   If it broke right after an upgrade, rename this folder and use
echo   the backup folder "...bak-YYYYMMDD-HHMMSS" instead.
echo  ------------------------------------------------------------
pause
exit /b 1
