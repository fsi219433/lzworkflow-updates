@echo off
REM ============================================================
REM  Linzhou Workflow - GUI launcher
REM
REM  NOTE: keep this file pure ASCII. Chinese bytes in a .bat break
REM  cmd under GBK codepage: UTF-8 Chinese bytes contain cmd
REM  metacharacters, which cmd treats as separators, so REM lines
REM  get executed as commands. Chinese user-facing text lives in
REM  HELP-runtime.txt and is printed with "type" AFTER chcp 65001.
REM ============================================================
chcp 65001 >nul 2>&1
cd /d "%~dp0"
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM -- cleanup: drop .py shadowed by .pyc (protected build has no source) --
for %%F in ("*.py") do if exist "%%~nF.pyc" del /q "%%~F" >nul 2>&1
for %%F in ("lib\*.py") do if exist "lib\%%~nF.pyc" del /q "lib\%%~F" >nul 2>&1
for %%F in ("bin\*.py") do if exist "bin\%%~nF.pyc" del /q "bin\%%~F" >nul 2>&1

REM -- resolve interpreter (bundled wins; must import openpyxl) --
if not exist "%~dp0_py.bat" (
  echo.
  echo  [!] _py.bat missing - this folder is incomplete.
  echo      Reinstall the full setup:  LZ-*-setup.exe
  echo.
  pause
  exit /b 1
)
call "%~dp0_py.bat"
if errorlevel 1 exit /b 1

set UIARG=
if exist "lib\ui_server.pyc" (set UIARG="lib\ui_server.pyc") else (set UIARG="lib\ui_server.py")

start "" %PYW% %UIARG% %*
timeout /t 4 /nobreak >nul

REM -- probe ports 8765..8774 via netstat (no PowerShell dependency) --
netstat -ano | findstr /r ":876[5-9] .*LISTENING" >nul 2>&1 && exit /b 0
netstat -ano | findstr /r ":877[0-4] .*LISTENING" >nul 2>&1 && exit /b 0

echo.
echo  ============================================================
echo   [!] UI failed to start. Details below:
echo  ============================================================
echo.
"%PYTHON%" %UIARG% --no-browser %*
echo.
echo  ------------------------------------------------------------
echo   Screenshot this and send to admin.
echo   Do not reinstall by hand yet - the error text above is
echo   the only thing that tells us what actually broke.
echo  ------------------------------------------------------------
pause
exit /b 1
