@echo off
REM Legacy entry point: forwards to the GUI launcher.
REM First run may download a portable Python runtime if missing.
REM NOTE: keep this file pure ASCII except the launcher name on the last call.
chcp 65001 >nul 2>&1
cd /d "%~dp0"

if not exist ".\python\python.exe" (
  echo.
  echo  ============================================================
  echo    First run - downloading portable Python 3.12 ^(~12 MB^)
  echo    Please keep the network connected.
  echo  ============================================================
  echo.
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-embed-amd64.zip' -OutFile 'python_embed.zip'"
  if not exist python_embed.zip (
    echo    [X] Download failed. Check network, or install Python 3.12 manually.
    pause
    exit /b 1
  )
  powershell -NoProfile -Command "Expand-Archive -Path 'python_embed.zip' -DestinationPath '.\python' -Force"
  del python_embed.zip >nul 2>&1
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile 'get-pip.py'"
  .\python\python.exe get-pip.py --quiet --no-warn-script-location
  del get-pip.py >nul 2>&1
  powershell -NoProfile -Command "$p='.\python\python312._pth'; if (Test-Path $p) { $c=Get-Content $p -Raw; $c=$c.Replace('#import site','import site'); Set-Content -Path $p -Value $c -NoNewline }"
  echo    Python ready.
)

call "%~dp0启动.bat"
