@echo off
REM 兼容旧入口：老用户可能双击这个文件 → 转发到图形界面启动器
REM （首次运行若无 python 运行时，引导下载后仍走 启动.bat）
chcp 65001 >nul 2>&1
cd /d "%~dp0"

if not exist ".\python\python.exe" (
  echo.
  echo  ============================================================
  echo    首次运行 - 正在下载便携版 Python 3.12（约 12 MB）
  echo    请保持网络连接。
  echo  ============================================================
  echo.
  powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-embed-amd64.zip' -OutFile 'python_embed.zip'"
  if not exist python_embed.zip (
    echo    [X] 下载失败。请检查网络，或安装 Python 3.12 后重试。
    pause
    exit /b 1
  )
  powershell -NoProfile -Command "Expand-Archive -Path 'python_embed.zip' -DestinationPath '.\python' -Force"
  del python_embed.zip >nul 2>&1
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://bootstrap.pypa.io/get-pip.py' -OutFile 'get-pip.py'"
  .\python\python.exe get-pip.py --quiet --no-warn-script-location
  del get-pip.py >nul 2>&1
  powershell -NoProfile -Command "$p='.\python\python312._pth'; if (Test-Path $p) { $c=Get-Content $p -Raw; $c=$c.Replace('#import site','import site'); Set-Content -Path $p -Value $c -NoNewline }"
  echo    Python ready.
)

call "%~dp0启动.bat"
