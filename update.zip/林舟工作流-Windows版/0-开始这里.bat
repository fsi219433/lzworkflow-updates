@echo off
REM Legacy entry point: forwards to the GUI launcher.
REM Runtime check + missing-runtime hint live in the root launcher and _py.bat.
REM NOTE: keep this file pure ASCII except the launcher name on the last call.
chcp 65001 >nul 2>&1
cd /d "%~dp0"
call "%~dp0启动.bat"
