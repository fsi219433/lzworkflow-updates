#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""依赖修复工具（Windows 版）—— 正常不用跑，出问题时双击 一键脚本/修依赖.bat

检查/安装: openpyxl(读写Excel) + pyperclip(剪贴板)
"""
import subprocess
import sys


def have(mod):
    try:
        __import__(mod)
        return True
    except ImportError:
        return False


def main():
    print("=" * 50)
    print("   林舟工作流 · 依赖检查")
    print("=" * 50)
    print(f"   Python: {sys.executable}")
    print(f"   版本  : {sys.version.split()[0]}")
    print()
    ok = True
    for mod, pkg in (("openpyxl", "openpyxl"), ("pyperclip", "pyperclip")):
        if have(mod):
            print(f"   [OK] {pkg} 已安装")
            continue
        print(f"   [--] {pkg} 未安装, 正在安装 ...")
        r = subprocess.run([sys.executable, "-m", "pip", "install", pkg,
                            "--no-warn-script-location"])
        if r.returncode != 0:
            ok = False
            print(f"   [X]  {pkg} 安装失败")
    print()
    print("   全部就绪。" if ok else "   部分依赖安装失败，请截图。")
    input("   按回车键退出...")


if __name__ == "__main__":
    main()
