@echo off
REM ============================================================
REM  Shared interpreter resolver.
REM    Usage (from package root):   call "%~dp0_py.bat"
REM    Usage (from sub-directory):  call "_py.bat"   (after cd to root)
REM  On success: sets PYTHON (console) and PYW (GUI), errorlevel=0.
REM  On failure: prints the missing-runtime hint and exits 1.
REM
REM  Order matters: the bundled runtime MUST win over a system Python.
REM  A machine may have Python 3.13 installed without openpyxl;
REM  picking that one gives ModuleNotFoundError on every task.
REM
REM  NOTE: keep this file pure ASCII. tools/build.py rejects non-ASCII
REM  bytes in .bat (cmd parses bats under GBK; UTF-8 Chinese bytes
REM  contain cmd metacharacters which get treated as separators).
REM ============================================================
set "PYTHON="
set "PYW="

if exist ".\python\python.exe"  set "PYTHON=.\python\python.exe"
if exist ".\python\pythonw.exe" set "PYW=.\python\pythonw.exe"
if not defined PYTHON ( where python >nul 2>&1 && set "PYTHON=python" )
if not defined PYW ( where pythonw >nul 2>&1 && set "PYW=pythonw" )
if not defined PYW if defined PYTHON set "PYW=%PYTHON%"
if not defined PYTHON goto _py_fail

REM -- the chosen interpreter must really be able to import openpyxl --
REM    Callers that only need the stdlib (install_deps / updater) pass
REM    --no-import-check, otherwise they can never run in the very
REM    situation they exist to fix.
if /i "%~1"=="--no-import-check" exit /b 0
"%PYTHON%" -c "import openpyxl" >nul 2>&1
if errorlevel 1 goto _py_fail
exit /b 0

:_py_fail
set "PYTHON="
set "PYW="
echo.
echo  ============================================================
echo   [!] Runtime missing: python.exe or openpyxl not available.
echo       This folder is an UPDATE package, not a full install.
echo       Install the full setup first:  LZ-*-setup.exe
echo       (Chinese detail below / see HELP-runtime.txt)
echo  ============================================================
echo.
if exist "%~dp0HELP-runtime.txt" type "%~dp0HELP-runtime.txt"
echo.
pause
exit /b 1
