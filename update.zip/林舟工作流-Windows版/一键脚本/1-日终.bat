@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set PYTHON=
python --version >nul 2>&1
if %errorlevel%==0 set PYTHON=python
if not defined PYTHON if exist ".\python\python.exe" set PYTHON=.\python\python.exe
if not defined PYTHON (
  echo.
  echo    [!] Python not found.
  echo        Please run the launcher bat at the package root first.
  echo.
  pause
  exit /b 1
)

REM 保护版是 menu.pyc / 源码版是 menu.py → 优先探测 pyc
if exist "menu.pyc" (
  %PYTHON% menu.pyc 1 %*
) else (
  %PYTHON% menu.py 1 %*
)
echo.
pause
