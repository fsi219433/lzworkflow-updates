@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set PYTHON=
python --version >nul 2>&1
if %errorlevel%==0 set PYTHON=python
if not defined PYTHON if exist ".\python\python.exe" set PYTHON=.\python\python.exe
if not defined PYTHON (
  echo.
  echo    [!] Python not found.
  echo        Please run the launcher bat at the package root first.
  echo.
  pause
  exit /b 1
)

REM Protected build ships menu.pyc; source build ships menu.py. Prefer .pyc.
if exist "menu.pyc" (
  %PYTHON% menu.pyc 2 %*
) else (
  %PYTHON% menu.py 2 %*
)
echo.
pause
