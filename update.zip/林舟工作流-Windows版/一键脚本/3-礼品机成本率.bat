@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

call "_py.bat"
if errorlevel 1 exit /b 1

REM Protected build ships menu.pyc; source build ships menu.py. Prefer .pyc.
if exist "menu.pyc" (
  %PYTHON% menu.pyc 3 %*
) else (
  %PYTHON% menu.py 3 %*
)
echo.
pause
