@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM Only stdlib is needed here, so no openpyxl requirement.
call "_py.bat" --no-import-check
if errorlevel 1 exit /b 1

echo.
echo  ============================================================
echo    Set update source (default: cloud; usually no change needed)
echo  ============================================================
echo.
echo   Leave blank and press Enter = use cloud source (recommended)
echo.
echo   Custom source (choose one):
echo    1) Network: http://192.168.1.x:8788/   ^(IP of the PC running the update server^)
echo    2) Folder : D:\share\update\     or a USB drive path
echo.

set /p SRC=  Address:

if "%SRC%"=="" set SRC=cloud:

%PYTHON% -c "import json,pathlib; p=pathlib.Path('update_config.json'); c=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}; c['source']=r'%SRC%'; c.setdefault('auto_check_on_start',True); c.setdefault('keep_backup',2); p.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8'); print('  [OK] written:', c['source'])"

echo.
echo   Testing connection...
if exist "lib\updater.pyc" (
  %PYTHON% lib\updater.pyc --check
) else (
  %PYTHON% lib\updater.py --check
)

echo.
pause
