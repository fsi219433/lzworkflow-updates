@echo off
chcp 65001 >nul 2>&1
REM ⚠️ 本脚本在「一键脚本\」子目录里 → 必须回到**包根**再操作
REM   （曾直接 cd %~dp0 导致配置写到子目录、找不到 lib\updater.py 而失败）
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set PYTHON=
python --version >nul 2>&1
if %errorlevel%==0 set PYTHON=python
if not defined PYTHON if exist ".\python\python.exe" set PYTHON=.\python\python.exe
if not defined PYTHON (
  echo [!] Python not found.
  pause
  exit /b 1
)

echo.
echo  ============================================================
echo    设置更新源（默认走云端，一般不需要改）
echo  ============================================================
echo.
echo  留空直接回车 = 恢复云端更新（推荐）
echo.
echo  如需自定义（二选一）:
echo    1) 网络源: http://192.168.1.x:8788/   ^(更新服务所在电脑的 IP^)
echo    2) 文件源: D:\共享\更新\      或  U盘路径
echo.

set /p SRC=  地址: 

if "%SRC%"=="" set SRC=cloud:

%PYTHON% -c "import json,pathlib; p=pathlib.Path('update_config.json'); c=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}; c['source']=r'%SRC%'; c.setdefault('auto_check_on_start',True); c.setdefault('keep_backup',2); p.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf-8'); print('  [OK] 已写入:', c['source'])"

echo.
echo   正在测试连接...
REM 保护版是 updater.pyc；源码版是 updater.py → 优先探测
if exist "lib\updater.pyc" (
  %PYTHON% lib\updater.pyc --check
) else (
  %PYTHON% lib\updater.py --check
)

echo.
pause
