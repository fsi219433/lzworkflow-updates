@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

REM This script exists to repair a broken dependency set, so it must NOT
REM require openpyxl to already be importable.
call "_py.bat" --no-import-check
if errorlevel 1 exit /b 1

%PYTHON% lib\install_deps.py
echo.
pause
