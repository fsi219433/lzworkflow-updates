@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0.."
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8

set PYTHON=
python --version >nul 2>&1
if %errorlevel%==0 set PYTHON=python
if not defined PYTHON if exist ".\python\python.exe" set PYTHON=.\python\python.exe
if not defined PYTHON (
  echo    [!] Python not found. Run the launcher bat at the package root first.
  pause
  exit /b 1
)

%PYTHON% lib\install_deps.py
